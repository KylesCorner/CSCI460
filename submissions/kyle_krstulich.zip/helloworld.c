#include <linux/kernel.h>
#include <linux/linkage.h>
#include <linux/syscalls.h>

//https://www.kernel.org/doc/html/latest/process/adding-syscalls.html
SYSCALL_DEFINE0(helloworld)
{
	printk(KERN_ALERT "Hello world!\n");
	return 0;
}

// this is for the old version 4 kernel
/*
asmlinkage long sys_helloworld(void) 
{ 
 	printk(KERN_ALERT "hello world\n"); 
	return 0; 
}
*/
