#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/uaccess.h> // to be able to copy to user space

SYSCALL_DEFINE3(csci_add, int, num1, int, num2, int __user *, result)
{
    int sum = num1 + num2;

    //alerting kernel
    printk(KERN_ALERT "csci_add: Adding %d and %d\n", num1, num2);
    printk(KERN_ALERT "csci_add: Result is %d\n", sum);

    // Copy result back to user space
    //https://manpages.debian.org/stretch-backports/linux-manual-4.11/__copy_to_user.9
    if (copy_to_user(result, &sum, sizeof(int)))
        return -EFAULT;  // Return error if copy fails

    return 0;
}

